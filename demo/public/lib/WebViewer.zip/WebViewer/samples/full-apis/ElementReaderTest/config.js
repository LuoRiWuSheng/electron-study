module.exports = {
  scriptName: 'ElementReaderTest.js',
  testFunction: 'runElementReaderTest'
};