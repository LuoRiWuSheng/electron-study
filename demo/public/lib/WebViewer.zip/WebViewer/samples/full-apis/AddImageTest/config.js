module.exports = {
  scriptName: 'AddImageTest.js',
  testFunction: 'runAddImageTest'
};