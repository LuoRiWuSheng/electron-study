module.exports = {
  scriptName: 'FDFTest.js',
  testFunction: 'runFDFTest'
};