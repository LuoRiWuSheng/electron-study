module.exports = {
  scriptName: 'WebViewerConvertTest.js',
  testFunction: 'runWebViewerConvertTest'
};