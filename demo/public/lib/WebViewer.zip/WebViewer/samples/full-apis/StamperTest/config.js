module.exports = {
  scriptName: 'StamperTest.js',
  testFunction: 'runStamperTest'
};