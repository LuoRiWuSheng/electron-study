module.exports = {
  scriptName: 'InteractiveFormsTest.js',
  testFunction: 'runInteractiveFormsTest'
};