module.exports = {
  scriptName: 'ElementEditTest.js',
  testFunction: 'runElementEditTest'
};