module.exports = {
  scriptName: 'EncTest.js',
  testFunction: 'runEncTest'
};