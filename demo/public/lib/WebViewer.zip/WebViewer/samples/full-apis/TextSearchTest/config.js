module.exports = {
  scriptName: 'TextSearchTest.js',
  testFunction: 'runTextSearchTest'
};