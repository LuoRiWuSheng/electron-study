module.exports = {
  scriptName: 'LogicalStructureTest.js',
  testFunction: 'runLogicalStructureTest'
};