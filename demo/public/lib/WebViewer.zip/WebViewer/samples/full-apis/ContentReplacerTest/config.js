module.exports = {
  scriptName: 'ContentReplacerTest.js',
  testFunction: 'runContentReplacer'
};