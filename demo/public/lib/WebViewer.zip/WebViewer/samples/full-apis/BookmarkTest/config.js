module.exports = {
  scriptName: 'BookmarkTest.js',
  testFunction: 'runBookmarkTest'
};