module.exports = {
  scriptName: 'PDFRedactTest.js',
  testFunction: 'runPDFRedactTest'
};