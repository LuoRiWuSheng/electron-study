module.exports = {
  scriptName: 'TextExtractTest.js',
  testFunction: 'runTextExtractTest'
};