module.exports = {
  scriptName: 'PDFLayersTest.js',
  testFunction: 'runPDFLayersTest'
};