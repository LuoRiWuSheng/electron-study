module.exports = {
  scriptName: 'PDFATest.js',
  testFunction: 'runPDFA'
};