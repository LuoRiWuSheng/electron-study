module.exports = {
  scriptName: 'SDFTest.js',
  testFunction: 'runSDFTest'
};