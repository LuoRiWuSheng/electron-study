module.exports = {
  scriptName: 'PDFPageTest.js',
  testFunction: 'runPDFPageTest'
};