module.exports = {
  scriptName: 'AnnotationTest.js',
  testFunction: 'runAnnotationTest'
};