module.exports = {
  scriptName: 'PDFDrawTest.js',
  testFunction: 'runPDFDrawTest'
};