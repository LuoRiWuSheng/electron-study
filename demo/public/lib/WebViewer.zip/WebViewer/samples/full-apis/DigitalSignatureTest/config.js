module.exports = {
  scriptName: 'DigitalSignatureTest.js',
  testFunction: 'runDigitalSignatureTest'
};