module.exports = {
  scriptName: 'OfficeToPDFTest.js',
  testFunction: 'runOfficeToPDF'
};