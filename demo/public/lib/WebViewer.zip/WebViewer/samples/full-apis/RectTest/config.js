module.exports = {
  scriptName: 'RectTest.js',
  testFunction: 'runRectTest'
};