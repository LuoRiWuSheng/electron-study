module.exports = {
  scriptName: 'ElementBuilderTest.js',
  testFunction: 'runElementBuilderTest'
};