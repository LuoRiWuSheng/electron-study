==========================
  WebViewer UWP Sample
==========================
This is a sample UWP application that supports offline viewing of XOD files where WebViewer is loaded in a WebView control.

Simply build and run the sample to get started.