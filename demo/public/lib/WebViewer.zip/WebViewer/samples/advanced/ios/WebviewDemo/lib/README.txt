This folder is a placeholder for the PDFTron WebViewer HTML5 source folder.
Please copy the contents of WebViewer\lib into this directory.