==========================
   WebViewer iOS Sample
==========================
This is a sample iOS mobile application that supports offline viewing of XOD files where the PDFTron WebViewer is loaded in a UIWebView.

Before you run the sample, please copy the entire folder WebViewer\lib to WebViewer\samples\advanced\iOS\WebviewDemo\lib.

Also copy samples\files\webviewer-demo-annotated.xod into the xod folder.