==========================
   WebViewer Android Sample
==========================
This is a sample Android mobile application that supports offline viewing of XOD files where the PDFTron WebViewer is loaded in an Android WebView control.
Included is a custom ContentProvider that allows users to open local .xod files from the device storage.


Before you run the sample, please copy the entire folder WebViewer\lib to WebViewer\samples\android\assets\lib.