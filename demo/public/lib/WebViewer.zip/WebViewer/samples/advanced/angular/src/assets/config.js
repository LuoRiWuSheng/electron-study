window.rotatePages = function() {
  readerControl.rotateCounterClockwise();
};