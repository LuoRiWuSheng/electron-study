# WebviewerApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.9.

## Steps to set up sample
1. Run `npm install` from the samples/angular directory
2. Run `npm run setup` to copy files to the necessary locations
3. Run `npm run start` to run the development server

For older browser support you may need to enable some polyfills https://angular.io/guide/browser-support#enabling-polyfills